% passes data is an array of structs { dom_str,sub_str}
function [l,T0,passes_data]=ezw_encode(mat,max_passes)
    l=length(mat);
    mat_orig=copy_matrix(mat);
    [mapping_row,mapping_col]=zorder(l);
    
    T=2^floor(log2(max(abs(max(max(mat))),abs(min(min(mat))))));
    T0=T;
    
    recon=zeros(l);
    dom=zeros(l);
    subord=zeros(l);
    
    passes=0;
    passes_data=[];
    
    while(T>=4)
        ztr_map=zeros(l);
        visited=zeros(l);
        cur_subord=zeros(l);
        
        [ret,ztr_map]=calculate_zero_tree_map(mat,ztr_map,T);
        
        ztr_map;
        
        dom_str='';
        refine_str='';
        
        % #define z_loop(zorder,c,i,j) for(c=0,p=zorder(c),i=p.first,j=p.second;c<n*n;c++,p=zorder(c),i=p.first,j=p.second)
        % dominant pass
        c=1; i=1; j=1;
        while c<=l*l
            i=mapping_row(c); j=mapping_col(c); c=c+1;
            
            [i,j];
            
            if visited(i,j)
                continue;
            end
            
            coeff=mat(i,j);
            
            if abs(coeff)>=T
                if(coeff>=0)
                    dom_str=[dom_str 'P'];
                else
                    dom_str=[dom_str 'N'];
                end
                dom_str;
                subord(i,j)=true; cur_subord(i,j)=true;
            else
                % fprintf('Not a P/N\n');
                if ztr_map(i,j)
                    ret=is_actual_zero_tree_root(ztr_map,i,j);
                    if ret
                        dom_str=[dom_str 'T'];
                        visited=mark_visited(visited,i,j);
                    end
                else
                    dom_str=[dom_str 'Z'];
                end
                
                dom_str;
            end
            
            visited(i,j)=true;
            
        end % zloop
        
        dom_str;
        
        % subordinate pass
        for i=1:l
            for j=1:l
                if cur_subord(i,j)
                    recon(i,j)=3*augsign(mat_orig(i,j))*T/2;
                end
                
                if subord(i,j)
                    err=mat_orig(i,j)-recon(i,j);
                    recon(i,j)=recon(i,j)+augsign(err)*T/4;
                    
                    if augsign(err)==-1
                        refine_str=[refine_str '0'];
                    else
                        refine_str=[refine_str '1'];
                    end
                end
            end % j
        end % i
        
        refine_str;
        
        recon;
        
        % set current dominant pass values to zero
        for i=1:l
            for j=1:l
                if cur_subord(i,j)
                    mat(i,j)=0;
                end
            end
        end
        
        T=T/2;
        
        pass_data.dom_str=dom_str;
        pass_data.refine_str=refine_str;
        
        passes_data=[passes_data pass_data];
        passes=passes+1;
        % break;
                    
    end % while T>=4
    
    recon
end

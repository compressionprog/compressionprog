#include "matrix.h"

ostream& operator<<(ostream& os,pair<int,int> p) {
	os<<"("<<p.first<<","<<p.second<<")";
	return os;
}

ostream& operator<<(ostream& os,Zorder& z) {
	for(int i=0;i<z.l*z.l;i++) os<<z(i)<<' ';
	return os;
}

int interleave(int a,int b,int l) {
	int v=0,bits=sizeof(int)*8;

	vector<int> aa,bb;

	for(int i=0;i<l;i++) {
		aa.push_back(a%2); a/=2;
		bb.push_back(b%2); b/=2;
	}

	// for(int i=0;i<l;i++) cout<<aa[i]; cout<<endl;
	// for(int i=0;i<l;i++) cout<<bb[i]; cout<<endl;

	for(int i=l-1;i>=0;i--) {
		v=v*2+aa[i]; 
		v=v*2+bb[i];
	}

	return v;
}

void loadfile(const char* fileName,string& s) {
	fstream f(fileName,ios::in);
	f.seekg(0,ios::end);
	int len=f.tellg();
	cout<<"len = "<<len<<endl;
	s.reserve(len);
	f.seekg(0);
	s.assign((istreambuf_iterator<char>(f)),istreambuf_iterator<char>());
}


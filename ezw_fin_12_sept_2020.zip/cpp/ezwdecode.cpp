#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <cmath>
#include "matrix.h"

using namespace std;

int mkword(int a,int b) { return (a<<8)|b; }

void stripr(string& s) {
	int i;
	for(i=s.length()-1;i>=0;i--) if(!isspace(s[i])) break;
	s=s.substr(0,i+1);
}

void mark_zero_tree_descendants(Matrix<int>& ztr_descendants,int i,int j) {
	int l=ztr_descendants.len();
	if(i>=l || j>=l) return;

  	ztr_descendants(i,j)=true;

  	if(!(i==0 && j==0))
    	mark_zero_tree_descendants(ztr_descendants,2*i,2*j);
  	mark_zero_tree_descendants(ztr_descendants,2*i,2*j+1);
  	mark_zero_tree_descendants(ztr_descendants,2*i+1,2*j);
  	mark_zero_tree_descendants(ztr_descendants,2*i+1,2*j+1);
}

string remove_Ts(string& s,int start,int end) {
	string r;

	for(int i=start;i<end;i++) {
		if(s[i]!='T') r+=s[i];
	}

	return r;
}

// T0 = 128
void decode(string& s,int T,int l,string outfilename="decoded.txt") {
	stringstream ss(s,ios::in);
	string dsl,ssl; // dominant pass string, subordinate pass string
	int pos=0,slen=s.length(),oldPos=pos,endPos=-1;
	int pass=0;

	Matrix<int> mat(l,l);
	Matrix<int> subord(l,l);
	Zorder zorder(l);

	cout<<"l = "<<l<<endl;

	cout<<"z = "<<zorder<<endl;

	while(!ss.eof()) {
		Matrix<int> ztr_map(l,l);
		Matrix<int> ztr_descendants(l,l);

		ss>>dsl>>ssl;

		cout<<dsl<<endl<<ssl<<endl;

		oldPos=pos;
		int c=0,i,j;
		for(pos=0;pos<dsl.length();pos++) {
			try {
				pair<int,int> p=zorder(c); //cout<<p<<endl;
				i=p.first; j=p.second;
				c++;
			} catch(char const *msg) {
				cout<<msg<<endl;
			}

			if(ztr_descendants(i,j) || subord(i,j)) {
				pos--; cout<<"skip\n";
				continue;
			}

			cout<<"2c = "<<c<<endl;


			if(dsl[pos]=='T') {
				ztr_map(i,j)=ztr_descendants(i,j)=true;
				mark_zero_tree_descendants(ztr_descendants,i,j);
				ztr_descendants(i,j)=false;
			} else {
				if(dsl[pos]=='P') {
					mat(i,j)=+3*T/2;  
					// cout<<"P\n";
				} else if(dsl[pos]=='N') {
					mat(i,j)=-3*T/2;
					// cout<<"N\n";
				}
				subord(i,j)=true;
			}
		}

		endPos=pos;

		cout<<"Pass "<<pass<<endl;
		cout<<"Dominant pass done\n";
		cout<<"ztr_descendants = \n"; cout<<ztr_descendants<<endl;


		cout<<"Finished dominant pass\n";
		cout<<"mat = \n"; cout<<mat<<endl;
		c=0; oldPos=pos;
		int spos=0;
		for(c=0;c<l*l;c++) {
			pair<int,int> p=zorder(c);
			i=p.first; j=p.second;

			if(subord(i,j)) {
				if(ssl[spos]=='0') {
					mat(i,j)-=T/4; spos++;
				} else if(ssl[spos]=='1') {
					mat(i,j)+=T/4; spos++;
				} else break;
			}
		}

		cout<<"Subordinate pass done\n";
		cout<<"mat = \n"; cout<<mat<<endl;

		pass++;
		T/=2;
	}

	mat.save(outfilename.c_str());
	//cout<<mat;
}

int main() {
	string s;
	struct _inputs {
		string name;
		int n;
		int T;
	}inputs[]={
		{"512x512",512,128},
		{"512x512_3",512,128},
		{"4x4",4,32},
		{"8x8",8,32}
	};
	string file_names[]={"512x512","512x512_3","4x4","8x8"};
	int idx=2;

	string in_file_name="encoded"+inputs[idx].name+".txt",out_file_name="decoded"+inputs[idx].name+".txt";
	loadfile(in_file_name.c_str(),s); stripr(s);
	decode(s,inputs[idx].T,inputs[idx].n,out_file_name.c_str());
	cout<<out_file_name<<endl;

	// loadfile("encoded4x4_3.txt",s); stripr(s);
	// decode(s,32,4,"decoded4x4.txt");

	// loadfile("encoded8x8_3.txt",s); stripr(s);
	// decode(s,32,8,"decoded8x8.txt");

	return 0;
}

/*

011 101

011011

*/
function [mapping_row,mapping_col] = zorder(l)
	mapping_row=zeros([1 l*l]);
	mapping_col=zeros([1 l*l]);
    for i = 0:(l-1)
        for j = 0:(l-1)
            index=1+interleave(i,j,log2(l)); % because of one based indexing
            mapping_row(index)=i+1; % similar
            mapping_col(index)=j+1; % similar
        end
	end
end


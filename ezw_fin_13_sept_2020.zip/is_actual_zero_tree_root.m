function ret=is_actual_zero_tree_root(ztr_map,i,j)
    if ~ztr_map(i,j)
        ret=false;
        return;
    end
    
    if i==1 && j==1
        ret=true;
        return;
    end
    
    ret=~ztr_map(1+floor((i-1)/2),1+floor((j-1)/2));
end
    
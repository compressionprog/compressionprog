function visited=mark_visited(visited,i,j)
    l=length(visited);
    
    mark_visited_inner(i,j);
    
    function mark_visited_inner(i,j)
        visited(i,j)=true;
        
        if(not (i==1 && j==1) && 2*i-1<=l && 2*j-1<=l) mark_visited_inner(2*i-1,2*j-1); end
        if(2*i<=l && 2*j-1<=l) mark_visited_inner(2*i,2*j-1); end
        if(2*i-1<=l && 2*j<=l) mark_visited_inner(2*i-1,2*j); end
        if(2*i<=l && 2*j<=l) mark_visited_inner(2*i,2*j); end
    end
end
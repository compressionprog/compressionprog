function [ret,ztr_map]=calculate_zero_tree_map(mat,ztr_map,T)
    l=length(mat);
    ret=calculate_zero_tree_map_inner(1,1);
    
    function ret=calculate_zero_tree_map_inner(i,j)
        if i>=l+1 || j>=l+1
            ret=true;
            return;
        end

        %  if(abs(mat(i,j))>=T) ztr_map(i,j)=false; else ztr_map(i,j)=true;

        ztr_map(i,j)=abs(mat(i,j))<T;

        a=1; b=1; c=1; d=1;

        if(not (i==1 && j==1) && 2*i-1<=l && 2*j-1<=l) a=calculate_zero_tree_map_inner(2*i-1,2*j-1); end
        if(2*i<=l && 2*j-1<=l) b=calculate_zero_tree_map_inner(2*i,2*j-1); end
        if(2*i-1<=l && 2*j<=l) c=calculate_zero_tree_map_inner(2*i-1,2*j); end
        if(2*i<=l && 2*j<=l) d=calculate_zero_tree_map_inner(2*i,2*j); end


        ztr_map(i,j)=ztr_map(i,j) && a && b && c && d;
        ret=ztr_map(i,j);
        ztr_map;
    end
end
function the_sign=augsign(x)
    the_sign=sign(x);
    
    if the_sign==0
        the_sign=-1;
    end
end
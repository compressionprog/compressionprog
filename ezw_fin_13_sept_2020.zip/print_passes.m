function print_passes(passes_data)
    for i=1:length(passes_data)
        passes_data(i)
    end
end

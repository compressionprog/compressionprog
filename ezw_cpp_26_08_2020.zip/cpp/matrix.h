#ifndef __MMATRIX_H_
#define __MMATRIX_H_
#include <iostream>
#include <fstream>
#include <cmath>
#include <vector>
#include <cstring>

using namespace std;

template<class T> class Matrix {
public: Matrix() { rows=cols=0; }

public:
	T *arr=NULL;
	int rows,cols;

	void zero() {
		for(int i=0;i<rows*cols;i++) arr[i]=T(0);
	}

	Matrix(int r,int c,bool zeroIt=true) : rows(r), cols(c) {
		arr=new T[rows*cols];

		if(zeroIt) zero();
	}

	void copy(Matrix& mat) {
		rows=mat.rows; cols=mat.cols;
		arr=new T[rows*cols];
		memcpy(arr,mat.arr,rows*cols*sizeof(T));
	}

	Matrix(Matrix& mat) {
		copy(mat);
	}

	Matrix(const char *filename,int n) {
		rows=cols=n;
		arr=new T[rows*cols];

		load(filename);
	}

	~Matrix() {
		if(arr) delete arr;
		arr=NULL;
	}

	//template<class T> friend ostream& operator<<(ostream&,Matrix&);

	T& operator()(int i,int j) {
		return arr[i*cols+j];
	}

	int len() { return rows; } // meanignful only for square matrix
	int size() { return rows; }

	void save(const char* filename) {
		fstream f(filename,ios::out);
		int c=0;

		for(int i=0;i<rows;i++) {
			for(int j=0;j<cols;j++) f<<arr[c++]<<' ';
			f<<endl;
		}

		f.close();
	}

	void load(const char* filename) {
		fstream f(filename,ios::in);
		int c=0;

		for(int i=0;i<rows;i++) {
			for(int j=0;j<cols;j++) f>>arr[c++];
		}

		f.close();
	}

	int count_trues() {
		int c=0;
		for(int i=0;i<rows*cols;i++) c+=arr[i]!=0;
		return c;
	}

	double rms(Matrix& mat) {
		double v=0;

		for(int i=0;i<rows*cols;i++) v+=pow(arr[i]-mat.arr[i],2);

		return sqrt(v/(rows*cols));
	}
};

ostream& operator<<(ostream& os,pair<int,int> p);

int interleave(int a,int b,int l);

class Zorder {
public:
	vector<int> row_map,col_map;
	int l; // size of matrix; length of z-order = l*l
	int k; // bit length of each index
	int c; // current index (related to iterating via foreach etc)

	Zorder(int ll,int c0=0) : l(ll),c(c0) {
		row_map.reserve(l*l);
		col_map.reserve(l*l);
		k=log2(l);

		for(int row=0;row<l;row++) {
			for(int col=0;col<l;col++) {
				int z=interleave(row,col,k);
				row_map[z]=row;
				col_map[z]=col;
			}
		}

		// cout<<"z-order for matrix of size "<<l<<" = \n";

		// for(int i=0;i<l*l;i++) cout<<"("<<row_map[i]<<","<<col_map[i]<<") "; cout<<endl;
	}
	
	pair<int,int> operator()(int i) {
		if(i>=l*l) {
			// cout<<"Z-order: attempt to access: "<<i<<", maximum = "<<(l*l-1)<<endl;
			//throw "Z-order out of bounds";
		}

		i%=l*l; // in a typical loop, l*l is accessed in the last iteration (and not used for anything, since the entry check stops the loop)
		        // this is done in order not to cause memory access caused crashes for that case

		return pair<int,int>(row_map[i],col_map[i]);
	}

	pair<int,int> operator++() {
		int old_c=c++;
		return (pair<int,int>){row_map[c],col_map[c]};
	}

	void reset() { c=0; }
};

ostream& operator<<(ostream& os,Zorder& z);

template<class T> ostream& operator <<(ostream& os,Matrix<T>& m) {
	int c=0;
	for(int i=0;i<m.rows;i++) {
		for(int j=0;j<m.cols;j++) {
			os<<m.arr[c++]<<' ';
		}
		cout<<endl;
	}
	cout<<endl;
}

void loadfile(const char* fileName,string& s);

#endif
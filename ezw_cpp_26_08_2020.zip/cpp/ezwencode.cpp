#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>
#include "matrix.h"
#define DEBUG 0

using namespace std;

#if 0
template<class TT> bool is_zero_tree_root_inner(Matrix<TT>& mat,int i,int j,int T,int& count) {
	if(i>=mat.rows && j>=mat.cols) return true;
	
	if(abs(mat(i,j))>T) return false;

	count++;

	bool a=true,b,c,d;

	if(!(i==0 && j==0)) a=is_zero_tree_root(mat,2*i,2*j,T,c);
	b=is_zero_tree_root(mat,2*i+1,2*j,T,c);
	c=is_zero_tree_root(mat,2*i,2*j+1,T,c);
	d=is_zero_tree_root(mat,2*i+1,2*j+1,T,c);

	return true;
}

template<class TT> bool is_zero_tree_root_inner(Matrix<TT>& mat,Matrix<TT>& visited,int i,int j,int T) {
	// if(is_zero_tree_descendant(ztr_map,i,j)) return false;

	int count=0;
	bool res=is_zero_tree_root_inner(mat,i,j,T);
	return res && count>1;
}

template<class TT> bool is_zero_tree_root2(Matrix<TT>& mat,int i,int j,int T) {
	if(i==0 && j==0) {
		for(int ii=0;ii<mat.len();ii++) for(int jj=0;jj<mat.len();jj++) if(mat(ii,jj)>=T) return false;
		return true;
	}

	int n;

	for(n=1;i+n<mat.len() && j+n<mat.len();n*=2,i*=2,j*=2) {
		for(int ii=i;ii<i+n;ii++) {
			for(int jj=j;jj<j+n;jj++) {
				if(mat(ii,jj)>=T) return false;
			}
		}
	}

	return n>2;
}

// template<class T> void mark_visited(Matrix<T>& mat,Matrix<bool>& visited,int i,j) {
// 	for(int n=1;i+n<mat.len() && j+n<mat.len();n*=2,i*=2,j*=2) {
// 		for(int ii=i;ii<i+n;ii++) {
// 			for(int jj=j;jj<j+n;jj++) {
// 				visited(i,j)=true;
// 			}
// 		}
// 	}
// }


template<class TT> void calculate_zero_tree_map2(Matrix<TT>& mat,Matrix<bool>& ztr_map,int T) {
	int n=mat.len();
	Matrix<bool> visited(n,n,true);
	int count=0;

	for(int i=0;i<mat.len();i++) {
		for(int j=0;j<mat.len();j++) {
			if(!visited(i,j)) {
				if(is_zero_tree_root(mat,i,j,T)) { ztr_map(i,j)=true; mark_visited(mat,visited,i,j); }
			}
		}
	}
}
#endif
// this one is O(n*n) ie optimal
template<class TT> bool calculate_zero_tree_map_inner(Matrix<TT>& mat,Matrix<bool>& ztr_map,int T,int i=0,int j=0) {
	static int count=0;
	count++;

	// cout<<i<<","<<j<<endl;

	if(i>=mat.rows || j>=mat.cols) return true;

	// cout<<":"<<i<<","<<j<<endl;

	if(abs(mat(i,j))>=T) ztr_map(i,j)=false; else ztr_map(i,j)=true;

	bool a=true,b=true,c=true,d=true;
	if(!(i==0 && j==0) && 2*i<mat.rows && 2*j<mat.cols) a=calculate_zero_tree_map_inner(mat,ztr_map,T,2*i,2*j);
	if(2*i+1<mat.rows && 2*j<mat.cols) b=calculate_zero_tree_map_inner(mat,ztr_map,T,2*i+1,2*j);
	if(2*i<mat.rows && 2*j+1<mat.cols) c=calculate_zero_tree_map_inner(mat,ztr_map,T,2*i,2*j+1);
	if(2*i+1<mat.rows && 2*j+1<mat.cols) d=calculate_zero_tree_map_inner(mat,ztr_map,T,2*i+1,2*j+1);

	ztr_map(i,j)=ztr_map(i,j) && a && b && c && d;

	// if(i==0 && j==0) cout<<"count = "<<count<<endl;

	return ztr_map(i,j);
}

#if 0
// ie parent must not be a ztr and it must not be a leaf node
bool is_zero_tree_descendant(Matrix<bool>& ztr_map,int i,int j) {
	if(!ztr_map(i,j)) return false; // obviously

	// if(i>=ztr_map.rows/2 || j>=ztr_map.cols/2) return false; // leaf node

	if(i==0 && j==0) return false; // root node

	return ztr_map(i/2,j/2);
}
#endif

// includes leaf nodes
bool is_actual_zero_tree_root(Matrix<bool>& ztr_map,int i,int j) {
	if(!ztr_map(i,j)) return false; // obviously

	// if(i>=ztr_map.rows/2 || j>=ztr_map.cols/2) return true; // leaf node

	if(i==0 && j==0) return true; // root node

	return !ztr_map(i/2,j/2);
}

template<class TT> bool is_leaf_node(Matrix<TT>& mat,int i,int j) {
	return i>=mat.rows/2 && j>=mat.cols/2;
}

template<class TT> bool calculate_zero_tree_map(Matrix<TT>& mat,Matrix<bool>& ztr_map,int T) {
	//cout<<"Calculating zero tree map\n";
	calculate_zero_tree_map_inner(mat,ztr_map,T);

	// cout<<"ztr_map before adjustment = \n";
	// cout<<ztr_map;

	// Zorder zorder(mat.size());
	// for(int c=0;c<mat.size()*mat.size();c++) {
	// 	pair<int,int> p=zorder(c);
	// 	int i=p.first,j=p.second;
	// 	if(!is_actual_zero_tree_root(ztr_map,i,j)) ztr_map(i,j)=false;
	// }

	int i,j,n=ztr_map.size();

	// set the leaf nodes to false
	// for(i=0;i<n/2;i++) {
	// 	for(j=0;j<n/2;j++) {
	// 		ztr_map(n/2+i,j)=false;
	// 		ztr_map(i,n/2+j)=false;
	// 		ztr_map(n/2+i,n/2+j)=false;
	// 	}
	// }

	// cout<<"ztr_map after adjustment = \n";
	// cout<<ztr_map;
}

// mark an element and all its descendants as visited
void mark_visited(Matrix<bool>& visited,int i,int j) {
	int n=visited.size();
	visited(i,j)=true;

	if(!(i==0 && j==0) && 2*i<n && 2*j<n) mark_visited(visited,2*i,2*j);
	if(2*i+1<n && 2*j<n) mark_visited(visited,2*i+1,2*j);
	if(2*j+1<n && 2*i<n) mark_visited(visited,2*i,2*j+1);
	if(2*i+1<n && 2*j+1<n) mark_visited(visited,2*i+1,2*j+1);
}

#define z_loop(zorder,c,i,j) for(c=0,p=zorder(c),i=p.first,j=p.second;c<n*n;c++,p=zorder(c),i=p.first,j=p.second)

int sgn(int x) {
	return x<=0?-1:1;
}

struct Encoded {
	int n,T0;
	vector<pair<string,string>> lines;

	int passes;
	int in_len,out_len;
	double compression_ratio;
	double rms_error;

	friend ostream& operator <<(ostream& os,Encoded enc);

	void print_lines() {
		for(auto p : lines) cout<<p.first<<endl<<p.second<<endl;
	}

	void write(const char *fileName) {
		fstream f(fileName,ios::out);
		f<<n<<' '<<T0<<endl;
		f<<passes<<endl;
		for(auto p : lines) f<<p.first<<endl<<p.second<<endl;
		f.close();
	}

	Encoded load(const char *fileName) {
		fstream f(fileName,ios::in);
		f>>n>>T0>>passes;
		string dom,sub;

		for(int i=0;i<passes;i++) {
			f>>dom>>sub;
			lines.push_back(pair<string,string>({dom,sub}));
		}
		f.close();
	}
};

ostream& operator <<(ostream& os,Encoded enc) {
	os<<enc.n<<'\t'<<enc.T0<<'\t'<<enc.passes<<'\t'<<enc.in_len<<'\t'<<enc.out_len<<'\t'<<enc.compression_ratio<<'\t'<<
	enc.rms_error;
	return os;
}

Encoded ezw_encode(Matrix<int>& mat_copy,int max_passes=-1) {
	Matrix<int> mat(mat_copy);
	int n=mat.size(),i,j,c;
	pair<int,int> p;
	int T,m=0,passes=0;

	Encoded enc;

	for(i=0;i<n;i++) {
		for(j=0;j<n;j++) m=max(m,abs(mat(i,j)));
	}

	T=enc.T0=pow(2,floor(log2(m)));

	#if DEBUG
	cout<<"T0 = "<<T<<endl;
	#endif

	Zorder zorder(n);
	Matrix<int> recon(n,n),dom(n,n),subord(n,n);

	int out_len=0;

	while(T>=4) {
		Matrix<bool> ztr_map(n,n),visited(n,n),cur_subord(n,n);
		calculate_zero_tree_map(mat,ztr_map,T);

		#if DEBUG
		cout<<"Pass "<<(passes+1)<<endl<<endl;
		cout<<"Calculated zero tree map\n";
		cout<<ztr_map;
		#endif

		string dom_str,refine_str;

		z_loop(zorder,c,i,j) {
			int coeff=mat(i,j);

			// cout<<coeff<<","<<i<<","<<j<<endl;

			if(visited(i,j)) continue;

			//cout<<"Not visited yet\n";

			if(abs(coeff)>=T) {
				//cout<<"Dominant\n";
				if(coeff>=0) dom_str+="P"; else dom_str+="N";
				subord(i,j)=cur_subord(i,j)=true;
			} else {
				if(ztr_map(i,j)) {
					if(is_actual_zero_tree_root(ztr_map,i,j)) { dom_str+="T"; mark_visited(visited,i,j); } 
				} else dom_str+="Z";
			}

			//cout<<dom_str<<endl;

			visited(i,j)=true;

			//cout<<"visited = \n"<<visited;
		}

		#if DEBUG
		cout<<"Dominant = "<<dom_str<<endl;
		#endif

		// subordinate pass
		for(i=0;i<n;i++) {
			for(j=0;j<n;j++) {
				if(cur_subord(i,j)) {
					recon(i,j)=3*sgn(mat_copy(i,j))*T/2;
				}  if(subord(i,j)) {
					int err=mat_copy(i,j)-recon(i,j);
					recon(i,j)+=sgn(err)*(T/4);

					if(sgn(err)==-1) refine_str+="0"; else refine_str+="1";
				}
			}
		}

		#if DEBUG
		cout<<"Refinement = "<<refine_str<<"\n";
		cout<<"Reconstruction matrix = \n"<<recon;
		#endif

		// set all new dominant pass values (ie the subord matrix) to zero
		for(i=0;i<n;i++) {
			for(j=0;j<n;j++) if(cur_subord(i,j)) mat(i,j)=0;
		}

		enc.lines.push_back({dom_str,refine_str});
		T/=2;
		out_len+=2*dom_str.length()+refine_str.length();
		passes++;
		if(passes==max_passes) break;

		//break;
	}

	cout<<"Output length (bits) = "<<out_len<<endl;
	cout<<"Input length = "<<n*n*8<<endl;
	cout<<"Compression ratio = "<<double(n*n*8)/double(out_len)<<endl;
	cout<<"rms error from original = "<<(enc.rms_error=mat_copy.rms(recon))<<endl;

	enc.n=n;
	enc.passes=passes;
	enc.in_len=n*n*8;
	enc.out_len=out_len;
	enc.compression_ratio=double(enc.in_len)/enc.out_len;
	enc.rms_error=mat_copy.rms(recon);

	return enc;
}

void print_all_passes(const char *file_name,int n) {
	Matrix<int> mat(n,n);
	mat.load(file_name);
	Encoded enc=ezw_encode(mat);

	cout<<enc<<endl;
	int passes=enc.passes;

	for(passes--;passes>0;passes--) cout<<ezw_encode(mat,passes)<<endl;
}

struct Decoded { 
	public:
	Matrix<int> mat;
	Decoded() {}
	Decoded(Matrix<int>& mmat) { mat.copy(mmat); }
	Decoded(Decoded &d) { mat.copy(d.mat); }
	//Decoded(Decoded d) { mat.copy(d.mat); }
};

void ezw_decode(Encoded & enc,Decoded& dec,Matrix<int> *p_orig_mat=nullptr,int max_passes=-1) {
	int n=enc.n,i,j,c,lineNo=0;
	Matrix<int> mat(n,n);
	pair<int,int> p;
	int T=enc.T0,m=0,passes=0;

	if(max_passes==-1) max_passes=enc.passes;

	cout<<"enc.passes = "<<enc.passes<<endl;

	//Decoded dec;

	#if DEBUG
	cout<<"T0 = "<<T<<endl;
	#endif

	Zorder zorder(n);
	Matrix<int> dom(n,n),subord(n,n);

	int out_len=0;

	for(passes=0;passes<min(enc.passes,max_passes);passes++) {
		Matrix<bool> ztr_map(n,n),visited(n,n),cur_subord(n,n);

		string &dom_str=enc.lines[passes].first,&refine_str=enc.lines[passes].second;
		#if DEBUG
		cout<<dom_str<<endl;
		#endif

		int pos=0;

		z_loop(zorder,c,i,j) {
			if(visited(i,j)) continue;
			//if(pos>=dom_str.length()) continue;

			#if DEBUG
			cout<<"i = "<<i<<", j = "<<j<<", pos = "<<pos<<", symbol = "<<dom_str[pos]<<endl;
			#endif

			switch(dom_str[pos]) {
				case 'P': mat(i,j)=3*T/2; subord(i,j)=cur_subord(i,j)=true; break;

				case 'N': mat(i,j)=-3*T/2; subord(i,j)=cur_subord(i,j)=true; break;

				case 'T': mark_visited(visited,i,j); break;

				case 'Z': break;
			}

			//cout<<dom_str<<endl;

			visited(i,j)=true;
			pos++;

			//cout<<"visited = \n"<<visited;
		}

		

		#if DEBUG
		cout<<"pos = "<<pos<<", dom_str length = "<<dom_str.length()<<endl;
		cout<<mat;
		#endif

		// subordinate pass
		pos=0;
		for(i=0;i<n;i++) {
			for(j=0;j<n;j++) {
				if(subord(i,j)) {
					//int err=mat_copy(i,j)-recon(i,j);
					//recon(i,j)+=sgn(err)*(T/4);

					if(refine_str[pos]=='0') mat(i,j)-=T/4; else mat(i,j)+=T/4;
					pos++;
				}
			}
		}

		#if DEBUG
		cout<<refine_str<<"\n";
		cout<<"subordinate pass done, pos = "<<pos<<", refine_str length = "<<refine_str.length()<<endl;
		cout<<mat;
		cout<<"-----------------------------\n";
		#endif

		T/=2;
		out_len+=2*dom_str.length();+refine_str.length();
		//break;
	}

	// cout<<"Output length (bits) = "<<out_len<<endl;
	// cout<<"Input length = "<<n*n*8<<endl;
	// cout<<"Compression ratio = "<<double(n*n*8)/double(out_len)<<endl;
	// cout<<"rms error from original = "<<(enc.rms_error=mat_copy.rms(recon))<<endl;

	// enc.n=n;
	// enc.passes=passes;
	// enc.in_len=n*n*8;
	// enc.out_len=out_len;
	// enc.compression_ratio=double(enc.in_len)/enc.out_len;
	// enc.rms_error=mat_copy.rms(recon);

	dec.mat.copy(mat);
}

int main() {
	//cout<<mat;
	//calculate_zero_tree_map(mat,ztr_map,32);
	//cout<<ztr_map<<endl;
	//cout<<ezw_encode(mat)<<endl;
	// print_all_passes("image512x512.txt",512);
	// print_all_passes("image8x8.txt",8);
	// print_all_passes("image4x4.txt",4);

	pair<string,int> inputs[]={{"image4x4.txt",4},{"image8x8.txt",8},{"image512x512.txt",512}};

	for(auto inp : inputs) {
		Matrix<int> mat(inp.first.c_str(),inp.second); //cout<<mat4<<endl;
		Encoded enc=ezw_encode(mat);
		cout<<"Encoded\n";
		//enc4.print_lines();
		Decoded dec;
		ezw_decode(enc,dec);
		cout<<"Decoded matrix = "<<endl<<dec.mat<<endl;
		cout<<"rms error = "<<dec.mat.rms(mat)<<endl;

		dec.mat.save(("decoded_"+inp.first).c_str());
		//cout<<"rms error = "
		//cout<<mat4;

		cout<<"--------------------------------------\n";
	}
	
	return 0;
}

function mat=ezw_decode(l,T0,passes_data)
    passes=length(passes_data);
    mat=zeros(l);
    
    lineNo=0;
    
    T=T0;
    m=0;
    passes=0;
    
    [mapping_row,mapping_col]=zorder(l);
    
    out_len=0;
    
    dom=zeros(l);
    subord=zeros(l);
    
    for pass=1:length(passes_data)
        ztr_map=zeros(l); visited=zeros(l); cur_subord=zeros(l);
        
        dom_str=passes_data(pass).dom_str;
        refine_str=passes_data(pass).refine_str;
        
        % #define z_loop(zorder,c,i,j) for(c=0,p=zorder(c),i=p.first,j=p.second;c<n*n;c++,p=zorder(c),i=p.first,j=p.second)
        
        c=1; i=1; j=1;
        pos=1;
        % dominant pass
        for c=1:l*l
            i=mapping_row(c); j=mapping_col(c);
            
            [i,j];
            
            if visited(i,j)
                continue
            end
            
            dom_str(pos);
            if dom_str(pos)=='P'
                %fprintf('In P\n');
                mat(i,j)=3*T/2;
                subord(i,j)=true; cur_subord(i,j)=true; % break;
            elseif dom_str(pos)=='N'
                % fprintf('In N\n');
                mat(i,j)=-3*T/2;
                subord(i,j)=true; cur_subord(i,j)=true; % break;
            elseif dom_str(pos)=='T'
                % fprintf('In T\n');
                visited=mark_visited(visited,i,j);
            elseif dom_str(pos)=='Z'
                %fprintf('In Z\n');
                % do nothing
            end
            
            visited(i,j)=true;
            
            pos=pos+1;
        end

        fprintf('Dominant pass done\n')
        visited;
        
        % subordinate pass
        pos=1;
        for i=1:l
            for j=1:l
                if subord(i,j)
                    if refine_str(pos)=='0'
                        mat(i,j)=mat(i,j)-T/4;
                    else
                        mat(i,j)=mat(i,j)+T/4;
                    end
                    pos=pos+1;
                end
            end
        end

        mat;
        
        T=T/2;
    end
    
    mat
end
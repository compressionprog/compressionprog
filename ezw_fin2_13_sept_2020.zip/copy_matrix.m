function new_mat=copy_matrix(mat)
    l=length(mat);
    new_mat=zeros(l);
    
    for i=1:l
        for j=1:l
            new_mat(i,j)=mat(i,j);
        end
    end
end
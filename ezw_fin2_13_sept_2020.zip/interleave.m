function v=interleave(a,b,l)
    aa=bitget(a,l:-1:1);
	bb=bitget(b,l:-1:1);
	arr=zeros([1,2*l]);

	arr(1:2:end)=aa;
    arr(2:2:end)=bb;
    
    v=0;
    
    for i = 1:2*l
        v=v*2+arr(i);
    end
end

% interleave(7,4,3)



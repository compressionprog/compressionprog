function bstr=passes_data_to_bitstream(passes_data)
    bstr='';
    
    for i=1:length(passes_data)
        dom_str=passes_data(i).dom_str;
        refine_str=passes_data(i).refine_str;
        
        %  (T=00,P=11,N=01,Z=10)
        for j=1:length(dom_str)
            c=dom_str(j);
            x='';
            
            if c=='T'
                x='00';
            elseif c=='P'
                x='11';
            elseif c=='N'
                x='01';
            elseif c=='Z'
                x='10';
            end
            
            bstr=[bstr x];
        end
        
        bstr=[bstr refine_str];
    end
end